import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FromaddrComponent } from './fromaddr.component';

describe('FromaddrComponent', () => {
  let component: FromaddrComponent;
  let fixture: ComponentFixture<FromaddrComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FromaddrComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FromaddrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
