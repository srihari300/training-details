import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fromaddr',
  templateUrl: './fromaddr.component.html',
  styleUrls: ['./fromaddr.component.css']
})
export class FromaddrComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
